# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models

class PM10_SVM(models.Model):
	pm_10_1_hour = models.IntegerField(null=False, blank=False)
	pm_10 = models.IntegerField(null=False, blank=False)

class PM10_LSTM_ARIMA(models.Model):
	measured_time = models.DateTimeField('Measured time')
	pm_10 = models.IntegerField(null=False, blank=False)