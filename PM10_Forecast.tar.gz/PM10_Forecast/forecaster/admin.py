# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
# Register your models here.
from .models import PM10_SVM
from .models import PM10_LSTM_ARIMA

admin.site.register(PM10_SVM)
admin.site.register(PM10_LSTM_ARIMA)