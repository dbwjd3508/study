# -*- coding: utf-8 -*-
import pandas as pd
from math import sqrt
import numpy as np
#import seaborn as sns
#import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import mean_squared_error
import plotly.offline as py
import plotly.graph_objs as go
import seleP as sel


def determine_level(pred, actual):
    true_val = 0
    false_val = 0
    
    for pm_pred, pm_act in zip(pred, actual):
        level = 0
        levelA = 0
        if pm_pred >= 31 and pm_pred <=80:
            level = 1
        elif pm_pred >= 81 and pm_pred <=150:
            level = 2
        elif pm_pred >= 151:
            level = 3
        
        if pm_act >= 16 and pm_act <=35:
            levelA = 1
        elif pm_act >= 36 and pm_act <=75:
            levelA = 2
        elif pm_act >= 151:
            levelA = 3
        
        if level == levelA:
            true_val+=1
        else:
            false_val+=1
    #print ("%d" % (true_val+false_val))
    acc = float(true_val)/float(true_val+false_val)
    return acc


def start_forecast(Si, Gu, Dong, today):

    #data = pd.read_csv('pm10.csv', index_col="date")
    #x = data.iloc[:, :-1]
    #y = data.iloc[:,-1]
    x, y = sel.start_crawling(Si, Gu, Dong, today)
    #print("finish")
    scaler = StandardScaler()
    scaler.fit(x)

    #print("?")

    x = scaler.transform(x)

    #print("??")

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)

    svc = SVC(kernel='rbf', C=10.0, gamma=0.1, random_state=0)

    svc.fit(x_train, y_train)

    #print("???")

    y_pred = svc.predict(x_test)

    #print("????")
    print(y_pred)

    #testY_reshape = y_test.reshape(len(y_test))
    #yhat_reshape = y_pred.reshape(len(y_pred))
    rmse = sqrt(mean_squared_error(y_test, y_pred))
    print('Test RMSE: %.3f' % rmse)
    print ("SVM accuracy: %.3f" % determine_level(y_pred, y_test))
    return y_pred