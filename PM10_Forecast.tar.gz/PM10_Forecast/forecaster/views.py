# -*- coding: utf-8 -*-
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import generic
from django.utils import timezone
import pandas as pd
import SVM_PM10 as svm
from datetime import datetime

def calc(Si, Gu, Dong, today):
	list1 = svm.start_forecast(Si, Gu, Dong, today)
	print("return to view")
	return list(list1[-4:])

def index(request):
	today = datetime.today().strftime("%Y%m%d")
	latest_forecast = calc("부산", "동구", "수정동", today)
	present_time = timezone.now()
	context = {'latest_forecast': latest_forecast, 'present_time': present_time}
	return render(request, 'forecaster/index.html', context)

def search(request, Si, Gu, Dong):
	present_time = timezone.now()
	return render(request, 'forecaster/search.html', context)