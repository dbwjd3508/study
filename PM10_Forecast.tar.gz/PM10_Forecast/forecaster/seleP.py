#-*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
import time
import sys
from operator import eq
import copy
reload(sys)
sys.setdefaultencoding('utf-8')

def start_crawling(Si, Gu, Dong, today):

    driver = webdriver.Firefox()
    #driver.page_source.encode('ascii', 'ignore')
    #driver.page_source.encode('utf-8')
    prefs = {"credentials_enable_service": False}
    driver.get("https://www.airkorea.or.kr/pmRelay?itemCode=10007")

    elem = Select(driver.find_element_by_id("district"))
    elem.select_by_visible_text(str(Si)) # change

    dateelem = driver.find_element_by_id("searchDate")
    day = today[-2:]
    mon = today[-4:-2]
    year = today[:4]

    searchlist = []

    month = int(mon)
    date = int(day)

    num = 0

    while True:
        if num == 16:
            break
        dat = str(date)
        mo = str(month)
        if len(dat) == 1:
            dat = "0"+dat
        if len(mo) == 1:
            mo = "0"+mo
        s = year + mo + dat
        #print(str(s))
        searchlist.append(s)
        date-=1
        if date < 1:
            month -= 1
            if month == 4 or month == 6 or month ==  9 or month == 11:
                date = 30
            elif month == 2:
                date = 28
            else:
                date = 31
        num+=1
    searchlist.reverse()

    list1=[]
    list2 = []
    ind = False

    for srr in searchlist:

        driver.execute_script("document.getElementById('searchDate').value = "+str(srr)+"""""") # iterate

        click_btn = driver.find_element_by_xpath('//input[@class="rt_btn mt5"][2]')
        click_btn.click()

        time.sleep(2)

        tablename = driver.find_element_by_xpath("//div[@id='bat3']/table[@id='tablefix1']/tbody")
        #tablebody = tablename.find_element_by_xpath("//tbody")

        index=1
        cnt=1
        flag=False
        s = "["+Si+" "+Gu+"]"+Dong # change
        #print(str(s))
        for name_row in tablename.find_elements_by_xpath(".//tr"):
            for td in name_row.find_elements_by_xpath(".//td"):
                if index == 2:
                    if str(td.text) == s:
                        flag = True
                    break
                index += 1
            if flag:
                break
            else:
                index = 1
                cnt+=1
    
        #print([td.text for td in name_row.find_elements_by_xpath(".//td")])

        tableelem = driver.find_element_by_xpath("//div[@id='bat4']/table[@id='tablefix1']/tbody")

        cnt2=1
        for row in tableelem.find_elements_by_xpath(".//tr"):
            if cnt2 == cnt:
                for td in row.find_elements_by_xpath(".//td"):
                    if str(td.text)!="-" and len(str(td.text))!=0:
                        list1.append([int(str(td.text))])
                        if ind:
                            list2.append(int(str(td.text)))
                        else:
                            ind = True
                #print([str(td.text) for td in row.find_elements_by_xpath(".//td")])
                break
            cnt2+=1

    list1.pop()
    print("list: ", list1)
    return list1, list2
